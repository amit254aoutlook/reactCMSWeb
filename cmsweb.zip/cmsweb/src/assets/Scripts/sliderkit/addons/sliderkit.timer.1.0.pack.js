/**
 *  Slider Kit Timer, v.1.0 (packed) - 2011/09/23
 *  http://www.kyrielles.net/sliderkit
 *  
 *  Copyright (c) 2010-2012 Alan Frog
 *  Licensed under the GNU General Public License
 *  See <license.txt> or <http://www.gnu.org/licenses/>
 *  
 *  Requires : jQuery Slider Kit v1.8+
 * 
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(2($){k.l.m=(2(a){4 b=n,5={8:1},6={3:b.9.o+\'-3\'};5=$.p({},5,a);7(b.q&&b.f!=\'\'){4 c=$(\'.\'+6.3,b.g);7(c.r()==0){b.s.t(\'<h u="\'+6.3+\'"></h>\');c=$(\'.\'+6.3,b.g)}4 d=2(){c.v().w(\'i\',1).j(b.x).y()};4 e=2(){d();7(b.f!=z){c.A().B({i:5.8,j:0},b.9.C-D,2(){})}};e();b.E.F(e)}})})(G);',43,43,'||function|timer|var|settings|csslib|if|fadeout|options||||||isPlaying|domObj|div|opacity|width|SliderKit|prototype|Timer|this|cssprefix|extend|arePanels|size|panelsBag|append|class|stop|css|domObjWidth|hide|null|show|animate|autospeed|100|panelAnteFns|push|jQuery'.split('|'),0,{}))