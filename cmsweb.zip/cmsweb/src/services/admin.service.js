import axios from "axios";
import authHeader from './auth-header';
import http from "../http-common";


const API_URL = "http://localhost:1337/api/";

class AdminService {  
  GetCategotyType(){
    return axios.get(API_URL + "categorytype/getall", { headers: authHeader() });
  }

  GetCategoryGroup(){
    return axios.get(API_URL + "categorygroup/Get", { headers: authHeader() });
  }

  CreateCategory(data){
    return http.post("category/create",data);
  }

  UpdateCategory(data){
    return http.post("category/update",data);
  }

  GetCategory(params){
    return http.get("category/getall", {params});
  }

  GetCategoryById(catid){
    return http.get("category/"+catid);
  }

  GetProgramType(){
    return http.get("programtype/get");
  }

  GetPrograms(params){
    return http.get("product/Get", {params});
  }

  GetMerchantProduct(prodid){
    return http.get("merchantproduct/get?pid="+prodid)
  }

  UploadScreenShot(data,productcode){
    //console.log(JSON.stringify(data))
    return http.post("uploadScreenshot/"+productcode,data);
  }

  UploadCatelog(data,productcode){
    return http.post("uploadCatalog/"+productcode,data);
  }

  UploadPackage(data,productcode){
    return http.post("uploadscormpackage/"+productcode,data);
  }

  CreateProduct(data){
    return http.post("product/create",data);
  }

  UpdateProduct(data){
    return http.post("product/update",data);
  }

  GetProgramById(id){
    return http.get("product/get/"+id)
  }
}

export default new AdminService();